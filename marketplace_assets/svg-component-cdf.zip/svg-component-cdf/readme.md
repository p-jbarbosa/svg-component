This folder contains the svg component code in a plugin form.
